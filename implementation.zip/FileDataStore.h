// FileDataStore.h
#pragma once
#include "IDataStore.h"
#include "Deck.h"
#include <fstream>
#include <iostream>
#include <sstream>
using namespace std;

class FileDataStore : public IDataStore
{
    string filename;
    int lastDeckId;
    int lastFlashcardId;

public:
    FileDataStore(const string& fname = "decks.txt");

    void saveDeck(const Deck& deck) override;
    Deck loadDeck(const string& id) override;
    vector<Deck> loadAllDecks() override;
    void exportDeck(const Deck& deck, const string& filename) override;
    Deck importDeck(const string& filename) override;
    void saveAllDecks(const vector<Deck>& decks);
    vector<Deck> loadAllDecksFromFile();
    int getNextDeckId();
    int getNextFlashcardId();
    void displayAllDecksInFile();

};



void FileDataStore::saveDeck(const Deck& deck)
{
    ofstream file(deck.getId() + ".txt");
    file << deck.getId() << "\n" << deck.getTitle() << "\n";
    for (const auto& card : deck.getCards())
    {
        file << card.getId() << "|" << card.getFront() << "|" << card.getBack() << "\n";
    }
    file.close();
}

Deck FileDataStore::loadDeck(const string& id)
{
    ifstream file(id + ".txt");
    if (!file) return Deck(id, "Unknown");
    string deckId, title;
    getline(file, deckId);
    getline(file, title);
    Deck deck(deckId, title);
    string line;
    while (getline(file, line))
    {
        istringstream iss(line);
        string cardId, front, back;
        getline(iss, cardId, '|');
        getline(iss, front, '|');
        getline(iss, back, '|');
        deck.addFlashcard(Flashcard(cardId, front, back));
    }
    file.close();
    return deck;
}
std::vector<Deck> FileDataStore::loadAllDecks()
{
    // For demo, return empty (could scan directory for *.deck files)
    return {};
}
void FileDataStore::exportDeck(const Deck& deck, const string& filename)
{
    saveDeck(deck); // For demo, just save as .deck file
    rename((deck.getId() + ".apkg").c_str(), filename.c_str());
}


Deck FileDataStore::importDeck(const std::string& filename)
{
    fstream file(filename);
    if (!file) return Deck("imported", "Imported");
    string deckId, title;
    getline(file, deckId);
    getline(file, title);
    Deck deck(deckId, title);
    std::string line;
    while (getline(file, line))
    {
        istringstream iss(line);
        string cardId, front, back;
        getline(iss, cardId, '|');
        getline(iss, front, '|');
        getline(iss, back, '|');
        deck.addFlashcard(Flashcard(cardId, front, back));
    }
    file.close();
    return deck;
}

// Constructor: load last used IDs if file exists
FileDataStore::FileDataStore(const string& fname) : filename(fname), lastDeckId(0), lastFlashcardId(0)
{
    ifstream file(filename);
    if (file)
    {
        std::string line;
        if (getline(file, line)) lastDeckId = stoi(line);
        if (getline(file, line)) lastFlashcardId = stoi(line);
    }
}

// Save all decks and last used IDs
void FileDataStore::saveAllDecks(const std::vector<Deck>& decks)
{
    ofstream file(filename);
    file << lastDeckId << "\n" << lastFlashcardId << "\n";
    file << decks.size() << "\n";
    for (const auto& deck : decks)
    {
        file << deck.getId() << "|" << deck.getTitle() << "|" << deck.getCards().size() << "\n";
        for (const auto& card : deck.getCards())
        {
            file << card.getId() << "|" << card.getFront() << "|" << card.getBack() << "\n";
        }
    }
    file.close();
}

// Load all decks and update last used IDs
vector<Deck> FileDataStore::loadAllDecksFromFile()
{
    vector<Deck> decks;
    ifstream file(filename);
    if (!file) return decks;
    string line;
    if (getline(file, line)) lastDeckId = std::stoi(line);
    if (getline(file, line)) lastFlashcardId = std::stoi(line);
    if (!getline(file, line)) return decks;

    int numDecks = std::stoi(line);
    for (int i = 0; i < numDecks; ++i)
    {
        if (!std::getline(file, line))
            break;

        istringstream iss(line);
        string deckId, title, numCardsStr;
        getline(iss, deckId, '|');
        getline(iss, title, '|');
        getline(iss, numCardsStr, '|');
        int numCards = std::stoi(numCardsStr);
        Deck deck(deckId, title);
        for (int j = 0; j < numCards; ++j) {
            if (!getline(file, line)) break;
            istringstream cardss(line);
            string cardId, front, back;
            getline(cardss, cardId, '|');
            getline(cardss, front, '|');
            getline(cardss, back, '|');
            deck.addFlashcard(Flashcard(cardId, front, back));
        }
        decks.push_back(deck);
    }
    file.close();
    return decks;
}


void FileDataStore::displayAllDecksInFile()
{
    std::vector<Deck> decks = loadAllDecksFromFile();
    std::cout << "Decks in file:\n";
    for (const auto& deck : decks) {
        std::cout << "ID: " << deck.getId() << ", Title: " << deck.getTitle() << "\n";
    }
}

// Unique ID generators
int FileDataStore::getNextDeckId()
{
    return ++lastDeckId;
}

int FileDataStore::getNextFlashcardId()
{
    return ++lastFlashcardId;
}