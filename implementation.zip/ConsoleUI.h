// ConsoleUI.cpp
#include <iostream>
using namespace std;
#include "FlashcardFacade.h"

class ConsoleUI
{
    FlashcardFacade& facade;
public:
    ConsoleUI(FlashcardFacade& f);
    void mainMenu();
};


ConsoleUI::ConsoleUI(FlashcardFacade& f) : facade(f) {}


void ConsoleUI::mainMenu()
{
    cout << "|=================================================================================================================|";
    cout << "\n|                                           **** CARDFLUENT ****                                                  |";
    cout << "\n|=================================================================================================================|\n";



    int choice;
    do
    {
        cout << "\n|================================================================================================|";
        cout << "\n|                                 ***  WELCOME TO CARDFLUENT MENU ***                            |";
        cout << "\n|================================================================================================|\n";

        cout << "\n|  ================= |";
        cout << "\n|1. Create Deck      |"
            << "\n|2. Add Flashcard    |"
            << "\n|3. Review Deck      |"
            << "\n|4. Delete Deck      |"
            << "\n|5. Show Progress    |"
            << "\n|6. Export Deck      |"
            << "\n|7. Import Deck      |"
            << "\n|8. Share Deck       |"
            << "\n|9. Show Leaderboard |"
            << "\n|10. Start Battle    |"
            << "\n|11. Show Decks      |"
            << "\n|12. Save            |"
            << "\n|13. Exit            |";
        cout << "\n|  ================= |\n";

        cout << "\n********************";
        cout << "\nEnter your choice: ";
        cin >> choice;
        cout << "\n********************\n";

        if (choice == 1)
        {
            cin.ignore();
            string title;
            cout << "Deck title: ";
            getline(cin, title);
            string id = facade.createDeck(title);
            cout << "Deck created with ID: " << id << "\n";
        }


        else if (choice == 2)
        {
            cin.ignore();
            string deckId, front, back;
            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

            cout << "Enter front content:\n";
            getline(cin, front);

            cout << "Enter back content:\n";
            getline(cin, back);
               
            string cardId = facade.addFlashcardToDeck(deckId, front, back);
            cout << "Flashcard added with ID: " << cardId << "\n";
        }

        else if (choice == 3)
        {
            cin.ignore();
            string deckId;
            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

            facade.reviewDeck(deckId);
        }


        else if (choice == 4)
        {
            cin.ignore();
            string deckId;

            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

       
            facade.deleteDeck(deckId);
            cout << "Deck deleted.\n";
        }

        else if (choice == 5)
        {
            cin.ignore();
            string deckId;

            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

        
            facade.showProgress(deckId);
        }

        else if (choice == 6)
        {
            cin.ignore();
            string deckId, filename;

            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

            cout << "Export filename: ";
            getline(cin, filename);
            facade.exportDeck(deckId, filename);
        }

        else if (choice == 7)
        {
            cin.ignore();
            string filename;
            cout << "Import filename: ";
            getline(cin, filename);
            facade.importDeck(filename);
        }
        else if (choice == 8)
        {
            string deckId, recipientId;

            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

        
            cout << "Recipient ID: ";
            cin >> recipientId;
            facade.shareDeck(deckId, recipientId);
        }

        else if (choice == 9)
        {

            facade.showLeaderboard();
        }

        else if (choice == 10)
        {
            string deckId;

            do
            {
                cout << "Deck ID: ";
                getline(cin, deckId);
            } while (deckId[0] != 'D');

         
            facade.startBattle(deckId);
        }


        else if (choice == 11)
        {
            FileDataStore f;
            f.displayAllDecksInFile();


        }


        else if (choice == 12)
        {
            
            facade.saveAll();
            cout << "\nDeck successfully saved." << endl;
        }

    } while (choice != 13);


}