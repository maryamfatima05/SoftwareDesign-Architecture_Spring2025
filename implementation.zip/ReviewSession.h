// ReviewSession.h
#pragma once
#include "Deck.h"

class ReviewSession
{
    Deck& deck;
    int currentIndex;
public:
    ReviewSession(Deck& deck);
    bool hasNext();
    Flashcard& next();
    void reset();
    int getCurrentIndex() const;
};

// ReviewSession.cpp
#include "ReviewSession.h"
ReviewSession::ReviewSession(Deck& d) : deck(d), currentIndex(0) {}
bool ReviewSession::hasNext() { return currentIndex < deck.getCards().size(); }
Flashcard& ReviewSession::next() { return deck.getCards().at(currentIndex++); }
void ReviewSession::reset() { currentIndex = 0; }
int ReviewSession::getCurrentIndex() const { return currentIndex; }