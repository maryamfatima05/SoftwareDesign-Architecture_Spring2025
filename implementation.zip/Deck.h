// Deck.h
#pragma once
#include <string>
#include <vector>
#include "Flashcard.h"
#include "Deck.h"
#include <algorithm>


class Deck {
    std::string id;
    std::string title;
    std::vector<Flashcard> cards;
public:
    Deck(const std::string& id, const std::string& title);
    std::string getId() const;
    std::string getTitle() const;
    void setTitle(const std::string& t);
    void addFlashcard(const Flashcard& card);
    void removeFlashcard(const std::string& cardId);
    void updateFlashcard(const std::string& cardId, const std::string& newFront, const std::string& newBack);
    const std::vector<Flashcard>& getCards() const;
    std::vector<Flashcard>& getCards();             // non-const version (for modification)
};



Deck::Deck(const std::string& id, const std::string& title) : id(id), title(title) {}
std::string Deck::getId() const { return id; }
std::string Deck::getTitle() const { return title; }
void Deck::setTitle(const std::string& t) { title = t; }
void Deck::addFlashcard(const Flashcard& card) { cards.push_back(card); }
void Deck::removeFlashcard(const std::string& cardId) {
    cards.erase(std::remove_if(cards.begin(), cards.end(),
        [&](const Flashcard& c) { return c.getId() == cardId; }), cards.end());
}
void Deck::updateFlashcard(const std::string& cardId, const std::string& newFront, const std::string& newBack) {
    for (auto& c : cards) {
        if (c.getId() == cardId) {
            c.setFront(newFront);
            c.setBack(newBack);
        }
    }
}
const std::vector<Flashcard>& Deck::getCards() const
{
    return cards;
}

std::vector<Flashcard>& Deck::getCards()
{
    return cards;
}