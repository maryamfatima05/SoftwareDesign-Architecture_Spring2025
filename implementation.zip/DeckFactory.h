// DeckFactory.h
#pragma once
#include "Deck.h"
#include "DeckFactory.h"
#include <sstream>
using namespace std;

class DeckFactory
{
    FileDataStore* dataStore;

public:
    DeckFactory(FileDataStore* ds) : dataStore(ds) {}

    Deck createDeck(const string& title)
    {
        int id = dataStore->getNextDeckId();
        return Deck("D" + to_string(id), title);
    }
};
