// Flashcard.h
#pragma once
#include <string>
#include "Flashcard.h"

class Flashcard
{
    std::string id;
    std::string front;
    std::string back;
public:
    Flashcard(const std::string& id, const std::string& front, const std::string& back);
    std::string getId() const;
    std::string getFront() const;
    std::string getBack() const;
    void setFront(const std::string& f);
    void setBack(const std::string& b);
};



Flashcard::Flashcard(const std::string& id, const std::string& front, const std::string& back)
    : id(id), front(front), back(back) {}
std::string Flashcard::getId() const { return id; }
std::string Flashcard::getFront() const { return front; }
std::string Flashcard::getBack() const { return back; }
void Flashcard::setFront(const std::string& f) { front = f; }
void Flashcard::setBack(const std::string& b) { back = b; }