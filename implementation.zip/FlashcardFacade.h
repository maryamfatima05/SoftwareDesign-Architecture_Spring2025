// FlashcardFacade.h
#pragma once
#include <string>
#include "Learner.h"
#include "FlashcardFactory.h"
#include "DeckFactory.h"
#include "ProgressTracker.h"
#include "ReviewSession.h"
#include "Leaderboard.h"
#include "BattleManager.h"
#include "IDataStore.h"
#include <iostream>

class FlashcardFacade
{
    IDataStore* dataStore;
    Learner* learner;
    ProgressTracker tracker;
    Leaderboard leaderboard;
    BattleManager battleManager;
    DeckFactory deckFactory;
    FlashcardFactory flashcardFactory;



public:
    FlashcardFacade(FileDataStore* ds, Learner* l);
    std::string createDeck(const std::string& title);
    std::string addFlashcardToDeck(const std::string& deckId, const std::string& front, const std::string& back);
    void removeFlashcardFromDeck(const std::string& deckId, const std::string& cardId);
    void updateFlashcardInDeck(const std::string& deckId, const std::string& cardId, const std::string& newFront, const std::string& newBack);
    void reviewDeck(const std::string& deckId);
    void deleteDeck(const std::string& deckId);
    void saveAll();
    void showProgress(const std::string& deckId);
    void exportDeck(const std::string& deckId, const std::string& filename);
    void importDeck(const std::string& filename);
    void shareDeck(const std::string& deckId, const std::string& recipientId);
    void showLeaderboard();
    void startBattle(const std::string& deckId);
};



FlashcardFacade::FlashcardFacade(FileDataStore* ds, Learner* l)
    : dataStore(ds), learner(l), battleManager(leaderboard),
    deckFactory(ds), flashcardFactory(ds) {}

std::string FlashcardFacade::createDeck(const std::string& title) {
    Deck deck = deckFactory.createDeck(title); // Use instance, not static
    std::string id = deck.getId();
    learner->addDeck(deck);
    return id;
}

std::string FlashcardFacade::addFlashcardToDeck(const std::string& deckId, const std::string& front, const std::string& back) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        Flashcard card = flashcardFactory.createFlashcard(front, back); // Use instance, not static
        deck->addFlashcard(card);
        tracker.updateProgress(deckId, deck->getCards().size());
        return card.getId();
    }
    return "";
}

void FlashcardFacade::removeFlashcardFromDeck(const std::string& deckId, const std::string& cardId) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        deck->removeFlashcard(cardId);
        tracker.updateProgress(deckId, deck->getCards().size());
    }
}

void FlashcardFacade::updateFlashcardInDeck(const std::string& deckId, const std::string& cardId, const std::string& newFront, const std::string& newBack) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        deck->updateFlashcard(cardId, newFront, newBack);
    }
}

void FlashcardFacade::reviewDeck(const std::string& deckId) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        ReviewSession session(*deck);
        session.reset();
        while (session.hasNext()) {
            Flashcard& card = session.next();
            std::cout << "Q: " << card.getFront() << "\n";
            std::string ans;
            std::cout << "Press enter to see answer...";
            std::cin.ignore();
            std::getline(std::cin, ans);
            std::cout << "A: " << card.getBack() << "\n";
            std::cout << "Rate recall (1=fail, 2=hard, 3=good, 4=easy): ";
            int rate;
            std::cin >> rate;
            tracker.updateStreak(deckId, rate >= 3);
        }
    }
}

void FlashcardFacade::deleteDeck(const std::string& deckId) {
    learner->removeDeck(deckId);
}

void FlashcardFacade::saveAll() {
    // This should call saveAllDecks on FileDataStore, not saveDeck for each deck
    FileDataStore* fds = dynamic_cast<FileDataStore*>(dataStore);
    if (fds) {
        fds->saveAllDecks(learner->getDecks());
    }
}

void FlashcardFacade::showProgress(const std::string& deckId) {
    std::cout << "Progress for deck " << deckId << ": " << tracker.getProgress(deckId) << " cards, Streak: " << tracker.getStreak(deckId) << "\n";
}

void FlashcardFacade::exportDeck(const std::string& deckId, const std::string& filename) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        dataStore->exportDeck(*deck, filename);
        std::cout << "Deck exported to " << filename << "\n";
    }
}

void FlashcardFacade::importDeck(const std::string& filename) {
    Deck deck = dataStore->importDeck(filename);
    learner->addDeck(deck);
    std::cout << "Deck imported: " << deck.getTitle() << " (ID: " << deck.getId() << ")\n";
}

void FlashcardFacade::shareDeck(const std::string& deckId, const std::string& recipientId) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        std::cout << "Deck " << deck->getTitle() << " shared with user " << recipientId << "!\n";
    }
}

void FlashcardFacade::showLeaderboard() {
    auto top = leaderboard.getTop(5);
    std::cout << "Leaderboard:\n";
    for (auto& p : top) {
        std::cout << p.first << ": " << p.second << "\n";
    }
}

void FlashcardFacade::startBattle(const std::string& deckId) {
    Deck* deck = learner->getDeckById(deckId);
    if (deck) {
        battleManager.startBattle(learner->getId(), *deck);
    }
}