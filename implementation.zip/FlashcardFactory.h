// FlashcardFactory.h
#pragma once
#include "Flashcard.h"
#include "FlashcardFactory.h"
#include <sstream>
using namespace std;

class FlashcardFactory
{
    FileDataStore* dataStore;
public:
    FlashcardFactory(FileDataStore* ds) : dataStore(ds) {}

    Flashcard createFlashcard(const string& front, const string& back)
    {
        int id = dataStore->getNextFlashcardId();
        return Flashcard("FC" + to_string(id), front, back);
    }
};


