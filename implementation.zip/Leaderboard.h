// Leaderboard.h
#pragma once
#include <map>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>  // for srand, rand
#include <ctime> 


class Leaderboard
{
    std::map<std::string, int> scores; // learnerId -> score
public:
    void updateScore(const std::string& learnerId, int score);
    std::vector<std::pair<std::string, int>> getTop(int n) const;
};


void Leaderboard::updateScore(const std::string& learnerId, int score) { scores[learnerId] += score; }


std::vector<std::pair<std::string, int>> Leaderboard::getTop(int n) const 
{
    std::vector<std::pair<std::string, int>> v(scores.begin(), scores.end());

    // Seed randomness only once per program run (safe to call multiple times, but seed should be outside ideally)
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    // Add random tie-breaker by shuffling first
    std::random_shuffle(v.begin(), v.end());

    // Then sort descending by score (stable, preserves random order on ties)
    std::stable_sort(v.begin(), v.end(), [](const auto& a, const auto& b) {
        return a.second > b.second;
        });

    if (v.size() > n) v.resize(n);
    return v;
}


