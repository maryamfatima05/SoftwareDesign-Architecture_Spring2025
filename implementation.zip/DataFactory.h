// DeckFactory.h
#pragma once
#include "Deck.h"
#include "DeckFactory.h"
#include <sstream>

class DeckFactory {
public:
    static Deck createDeck(const std::string& title);
};

// DeckFactory.cpp

Deck DeckFactory::createDeck(const std::string& title)
{
    static int id = 1;
    std::ostringstream oss;
    oss << "D" << id++;
    return Deck(oss.str(), title);
}