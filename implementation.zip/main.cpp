#include "FileDataStore.h"
#include "Learner.h"
#include "FlashcardFacade.h"
#include "ConsoleUI.h"
using namespace std;

int main()
{
    FileDataStore dataStore;
    // Load all decks from file
    vector<Deck> decks = dataStore.loadAllDecksFromFile();
    Learner learner("1", "Student");

    for (int i = 0; i < decks.size(); ++i)
    {
        learner.addDeck(decks[i]);
    }

    FlashcardFacade facade(&dataStore, &learner);
    ConsoleUI ui(facade);
    ui.mainMenu();
    // Save all decks to file on exit
    dataStore.saveAllDecks(learner.getDecks());
    return 0;

}