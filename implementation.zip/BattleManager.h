// BattleManager.h
#pragma once
#include "Deck.h"
#include "Leaderboard.h"
#include <string>
#include <vector>
#include "BattleManager.h"
#include <iostream>
using namespace std;


class BattleManager
{
    Leaderboard& leaderboard;
public:
    BattleManager(Leaderboard& lb);
    void startBattle(const std::string& learnerId, Deck& deck);
};



BattleManager::BattleManager(Leaderboard& lb) : leaderboard(lb) {}

void BattleManager::startBattle(const string& learnerId, Deck& deck)
{
    int score = 0;
    cout << "Starting battle quiz!\n";

    cin.ignore();
    for (int i = 0; i < deck.getCards().size(); ++i)
    {
        auto& card = deck.getCards()[i];

        std::cout << "Q: " << card.getFront() << "\n";

        std::string ans;
        std::cout << "Your answer: ";
        std::getline(std::cin, ans);

        if (ans == card.getBack())
        {
            std::cout << "Correct!\n";
            score += 10;
        }
        else
        {
            std::cout << "Wrong! Correct answer: " << card.getBack() << "\n";
        }
    }


    leaderboard.updateScore(learnerId, score);
    cout << "Battle finished! Your score: " << score << "\n";
}