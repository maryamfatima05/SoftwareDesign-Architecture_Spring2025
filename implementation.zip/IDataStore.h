#pragma once
#include <vector>
#include "Deck.h"

class IDataStore
{
public:
    virtual void saveDeck(const Deck& deck) = 0;
    virtual Deck loadDeck(const std::string& id) = 0;
    virtual std::vector<Deck> loadAllDecks() = 0;
    virtual void exportDeck(const Deck& deck, const std::string& filename) = 0;
    virtual Deck importDeck(const std::string& filename) = 0;
    virtual ~IDataStore() {}
};