// Learner.h
#pragma once
#include <string>
#include <vector>
#include "Deck.h"

class Learner {
    std::string id;
    std::string name;
    std::vector<Deck> decks;
public:
    Learner(const std::string& id, const std::string& name);
    void addDeck(const Deck& deck);
    void removeDeck(const std::string& deckId);
    std::vector<Deck>& getDecks();
    Deck* getDeckById(const std::string& deckId);
    std::string getId() const;
    std::string getName() const;
};

// Learner.cpp
#include "Learner.h"
Learner::Learner(const std::string& id, const std::string& name) : id(id), name(name) {}
void Learner::addDeck(const Deck& deck) { decks.push_back(deck); }
void Learner::removeDeck(const std::string& deckId) {
    decks.erase(std::remove_if(decks.begin(), decks.end(),
        [&](const Deck& d) { return d.getId() == deckId; }), decks.end());
}
std::vector<Deck>& Learner::getDecks() { return decks; }
Deck* Learner::getDeckById(const std::string& deckId) {
    for (auto& d : decks) if (d.getId() == deckId) return &d;
    return nullptr;
}
std::string Learner::getId() const { return id; }
std::string Learner::getName() const { return name; }