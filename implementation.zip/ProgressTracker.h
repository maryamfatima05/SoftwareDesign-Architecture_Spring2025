// ProgressTracker.h
#pragma once
#include <map>
#include <string>
#include "ProgressTracker.h"


class ProgressTracker
{
    std::map<std::string, int> progress; // deckId -> progress
    std::map<std::string, int> streaks;  // deckId -> streak
public:
    void updateProgress(const std::string& deckId, int value);
    int getProgress(const std::string& deckId) const;
    void updateStreak(const std::string& deckId, bool correct);
    int getStreak(const std::string& deckId) const;
};


void ProgressTracker::updateProgress(const std::string& deckId, int value) { progress[deckId] = value; }
int ProgressTracker::getProgress(const std::string& deckId) const {
    auto it = progress.find(deckId);
    return (it != progress.end()) ? it->second : 0;
}
void ProgressTracker::updateStreak(const std::string& deckId, bool correct) {
    if (correct) streaks[deckId]++;
    else streaks[deckId] = 0;
}
int ProgressTracker::getStreak(const std::string& deckId) const {
    auto it = streaks.find(deckId);
    return (it != streaks.end()) ? it->second : 0;
}